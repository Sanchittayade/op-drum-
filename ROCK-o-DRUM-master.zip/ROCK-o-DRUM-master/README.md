# ROCK-o-DRUM
## VIRTUAL DRUMS?
Yeah, you heard it right.
### OpenCV,Numpy and Pygame are the modules needed to run the code successfully.
Just change the value of x in VideoCapture(x) to 0 or 1 depending on the camera used.0-Webcam 1-External device.
### To play with the drums:
Run the file, take a red or a blue colour object and hit the drums as shown by your camera.

